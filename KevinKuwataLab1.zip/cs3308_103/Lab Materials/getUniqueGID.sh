#!/bin/bash

sort -u --key=1 password_demo.txt > tmp


