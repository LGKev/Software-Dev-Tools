#!/bin/bash

sed 's/4/a/g; s/7/t/g; s/0/o/g; s/1/i/g;  s/3/e/g; s/5/s/g' cryptic.txt

